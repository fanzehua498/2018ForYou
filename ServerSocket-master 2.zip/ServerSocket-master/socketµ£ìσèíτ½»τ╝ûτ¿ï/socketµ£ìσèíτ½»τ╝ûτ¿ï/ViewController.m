//
//  ViewController.m
//  socket服务端
//
//  Created by ZH on 16/10/15.
//  Copyright © 2016年 ZH. All rights reserved.
/**
 /9j/4AAQSkZJRgABAQAASABIAAD/4QBMRXhpZgAATU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAgKADAAQAAAABAAAAgAAAAAD/7QA4UGhvdG9zaG9wIDMuMAA4QklNBAQAAAAAAAA4QklNBCUAAAAAABDUHYzZjwCyBOmACZjs+EJ+/8AAEQgAgACAAwEiAAIRAQMRAf/EAB8AAAEFAQEBAQEBAAAAAAAAAAABAgMEBQYHCAkKC//EALUQAAIBAwMCBAMFBQQEAAABfQECAwAEEQUSITFBBhNRYQcicRQygZGhCCNCscEVUtHwJDNicoIJChYXGBkaJSYnKCkqNDU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6g4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2drh4uPk5ebn6Onq8fLz9PX29/j5+v/EAB8BAAMBAQEBAQEBAQEAAAAAAAABAgMEBQYHCAkKC//EALURAAIBAgQEAwQHBQQEAAECdwABAgMRBAUhMQYSQVEHYXETIjKBCBRCkaGxwQkjM1LwFWJy0QoWJDThJfEXGBkaJicoKSo1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoKDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uLj5OXm5+jp6vLz9PX29/j5+v/bAEMAAgICAgICAwICAwUDAwMFBgUFBQUGCAYGBgYGCAoICAgICAgKCgoKCgoKCgwMDAwMDA4ODg4ODw8PDw8PDw8PD//bAEMBAgICBAQEBwQEBxALCQsQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEP/dAAQACP/aAAwDAQACEQMRAD8A/fyiiigAooooAKazhOtKTwa/Ib9vj/goynwVvbr4LfA94tR+ITLsvb9gJbfSNwB2hSCslzt5wfkj6uCfloA+7/j5+1R8EP2bNIXUvip4ijsrq4QvbadAPP1C5x/zygT5sZ43ttQd2Ffjv8Sf+CyvxA1y4nsvgX8PLbT7TJVL7W5WuJCOx8mFo40PsZHr8ir241Txzq9z428caxceJtZ1NzJPdXcrzM757s/Jx0HYDgDFaYAUBVGAOg9PpQB9S+Jv2+f24PGTyG7+JH9hwvnEOl2tvbhM9g6xGT/yITXmf/DSv7WizG6X4z+I/OJBJN9Nt49t+P0ryfrR0oA+sPCv/BQb9t/wUyGHx/F4kgQD9zqtnBMD9X8tJP8AyJX2F8Nf+Cyni7Tbq3s/jv8ADmKWyJVZL/QZWR0H977POzqx68CVfavyNo6Z96AP68vgZ+1D8D/2i9JOo/CjxNBqs8KBrixfMF9bg/8APW3kw4HbcAVPZjX0ArBxkDFfxD6ReeJPBXiSx8c/DrVJ/D/iLS5BLb3NrIYmDD0xxz0IOVYcMCK/pB/YJ/b4sf2mLCT4efEMwaP8TNJj3PCg8qHVIUHzTwIT8si9ZYgeB8y/LkKAfpzRRRQB/9D9/KKKKACiimt0oA+HP2/P2pB+y78Dr3W9FmX/AITDxEW07Q4yAxSdlzLclT1W3Q7vQuUB4NfydXSald3OdVnkuda8QSvPeXErF5SHYvIWY8lnJJYnqa/Qv/gpn8WH+Lv7XV74XtZPN0T4b2yabEoOUa6P725bHr5rCM+0Yr88LjVEtNe1C9nhlnMCCNNoyAByzE9B/wDXoA7WGGK3iSGEbUQBQPYVLX3T8Hv+Cbv7UPxk8N6T4yV9E8JaDrdtFeWs19dNc3ElvOoeNxFbq4GVIIDFT2IFfWuh/wDBGS8mjDeLfjHcFzyyWGlLEv0DSTk/jj8KAPxhor9yn/4IxeBNmIfivr6v6tbW7D8sj+dcpqv/AARhu1iK+HPjNcK3YXekJIPxK3ANAH4wUV+nXib/AIJF/tKaPE83hLxn4d8R7OkVwk9jI3sPkkX82r4F+Of7PP7QnwQsJx8U/At9o9osiBNSt8XWnsdwx/pEJZBn0Yg9sUAef0yy1nxL4L8Q6b8QvAt9JpfiTQJkurW5hOHVojn6HjIIOQykqcg4pUbcit6gH86d70Af1zfsofH3TP2lfgd4d+KdkEhvbyLyNSt06W2oQYW4jAPO3d86Z/gZa+jq/Bb/AIIw+OpLTWPip8IJZP3CG01u1jzwu7ME5A7ZBhB+gr96aAP/0f38ooooAKp313FZWc97N/q7eN5G/wB1ASf5VcrH1zTbfXNGv9FnZliv4JbeQxttdVlQoxUjoQDwe1AH8QmpeOh4n8c694o1FzNfeKdVur2WQnkG4lZwW+pY/pU/iCZYtEvNx+8hUfVuK/an4kf8EXtLj8PaUnwV8abNatLi4luptcjLLcRvs8hE+zgrH5W1snYd5YkkYAr5Y/Y+/Yq8S/Fr9pfV9C8aXtprPgb4U6oE1m7sg32O/v7ZjssoC6ozguD5pxgID/eXIB+/Hwy8KeINH/Zn8B+E7VpYdR0/w1p1vKkMghkaRLFQY1lOdhL4Abt1r8jvE/xS/a8+ADWGu2PisDV7W/Mcvwy1K8fV74Wk2VW6W+I3zxZw4AbCBhknkD9/WjXygmOAAAB04r5g8Y/G7wNb67eaJcalBoNzoaG51Wa8tGuZlsYjmVUVAWVWXkyt8qjsTQB4xD8Qv2z9c+FOl/FbwZ4S0/8AtrVbYC48OajIVmhYvgXELhghQKN2xiGYH2xXwz4Q+MX7UPi2wu/F3xI8cPquuwzEW/gDRdUXw94gf9+YywhEDK6gDeqbizRjOeef1Pv/ANrr9lzTdJs9Vb4peHYbW9jRrdvt8ZZkOdoCKS46YwVB9qxfFnxh8LaPZ2vxY1/w/b618PphCbfX4bUveWSy4UyywSoJWt92D5sfQHlcDNAFz9njxj8cfEzz2/xL8Hal4XsbdPk/tqa0nu2bjaqTWbbZQMnLPGjfWvIP+Cp+pJp37FHjSHcFe/uNLtkHqXvYWI/JSfwr6/8Ah98SfAvxGsBqngfVk1aykJIljDbGHXKkjkDpmvyu/wCCyHxMsLT4beBPg7FcqL3xLq/9pTx55Wz09GUFvQNLKNuepU+lAH4VRrtjVf7oA/Kn0rdST3NVLq8tbNo1upViMp2ru7k/56nigD9H/wDgkzPcQ/tfa5FCT5dz4TufNwf7txbFf1Ar+l5egr8BP+CNvw21HUvGXxF+OV1A8emJbRaDYyMCFld5FnnK9jsWOLOOm/Ffv2OBigD/0v38opCcV8g/tXfth/Dv9lzw/GNWRtd8YaspGk6DasPtNy3QSSkZ8qAHhnYc8hQxzioxbdktRpNuyPW/jd8d/hr+z34Lm8efE/VV03T0JSGJR5lzdzYysNvECGkc+g4A5Ygc1/Pd8c/2xv2iv2gvEkHiXwvrF18M/Duiym40TTbOUpcSyq2Y59QdT85bGPLI2AHhTyzeQeP/ABv8RPjl47f4q/GjURqOsnK2NhHxY6VBuyIreMkjI7tySeSSeapNlgSeSfWv1/hjw6i4e2zFb7R7ebffy6dex+g5JwgnH2mL67L/AD/y/wCGP6C/2Pf2qIf2nvhHcalJFHp/jzw8hs9b08fKYr0KfLmjXP8AqZ8blPY7lyduT4d/wSb1bRrr9njX9HV1HibT/FGqHXIjgTLczMpRnHXDIoAJ7qw7V+QXw0+Kvij9m/4qab8cPBcT3Udsv2bXdOQ7V1HTWI8wHt5keNyN2YA9AQf031r4D+OL/wAUxftuf8E7fFNnv8cQrd6t4evSqWGqFzulHJ2xzb8+ZG5QpJuKyKSQfzviLIqmX4l0J6rdPuv63Pks4yueErOnLbo+6P2KJOMV4B4gm1LS77xFqPwt8PaXrfiueeNL1L+drDfBtwqG4EMpbkHCkY5r4O0v/gq54N8D63N4C/aW+HuufD/xdpoQXsNusd/bIWUMHGHSQKQQwG1uDwxr3Oz/AG6f2E/ihpd5ZXHxD061j1aHyLlL5LjTpHTkAM8qR4IzkENkHoa8I8oyNG+EfxBMkXj/AMP/AAB8GeCfGO+SYOdSiK/OcOLgwWL5LD5hs4z1Oa9Wh8R/tDa40sd/pHgyC0ttqyG2vrvU7iNG4bCNbxREn+EFsetfMvgf4P8A7I2o69aX9t+0ZqHizQ7Zy66DeeMleyZdweKN41mSRo0I+6xIbo2RxX3VffFv9nrR9PWwvPHXhrTLWLBCf2rZwKMe3mAYoA1PhD4J0XwT4eNlottHbRTyyTMI41jzJK258BQABk9ABiuX+OX7LPwM/aMtLSD4u+GYtZn09WS1ulkkt7q3VyCypNCyttJGdpyuecZzXmHiz9vv9jj4eWbi++JmmXrQgkQ6az6hI59B9nVxkn1IHvXwR8UP+Cqnjj4gaJr1l+yP8ONSvV0m3knute1KJWW0iRctKlrGXUsF5USOf+uZoA+V/wBqf9h74Z+Bvj74B/Z9/Zu8Q6veeMfF8xkvrK8njuYNKsCMrPIyIjj5Q8m1iTsT/aUn3a2/4It61e2+rjxN8VIri7H2ddNmg091REEmZzPE0nJMfCBX4bkkjivqj/gmL8LvAN98Ppv2nZfEM3jn4i+PnmXWdUvR+/spY3/e2SKSxXDBWZ8/OuwqFQKK/VWgDyr4K/CDwf8AAj4aaH8LPAsJi0nQ4PLVnwZZpGJaWaUgDMkjksx98DAAFeq0UUAf/9P9+yM1+Vf/AAUl/ZW1j4iaJaftC/DK0Nz4z8EWzJeWaDLanpK5eSMAcmWHLMmOWUsoydor9VaZJjY2fStaFedKcalN2ad0/NGlKrKElODs0fyF6LrGn6/pkGrac++C4HAP3lYdVYeo7/4YrXr7Q/b5/ZRuPgN4rvf2gvhpp5bwD4huA3iCwgU40u9lbi8iReFglY/MOiuccKy7fie2uIrmGO4tpFlhlUOjryrKehB9K/pPhTiSGY4fm2mviXn3Xk/+B6/suRZzHGUubaS3X6+jJzgAn866j4X/ALVnxV/Y30rxVp3w/ij1Hw54tt5Ta21wSYdI1hhhbuJcEEFc5jOFchc/cwfMvE3izRPClqtxrE+0yA+XEg3SSY/ujjAzxk4HvnivsH9kz9gzx3+0nq1j8UPjvYXHhv4aW7Cay0ht0N3qvQgt0aOBh1k4Zh8sYAO8fN+IuPwLw3sKjvVWyW69eya6ddNOq8bjDFYZ0fZTd59Lbr18vLr+J6X+yn8IvD+h+CE+KWr38fjHxf8AECH+0NS1eYi43LcHe1sjSAnhuJiQC0gIIwiivZtc+BnwW8Ruz674F0W6dzuaQ2MUTk98vEqNz9a+afiv4Q8af8E1/HJFjdJ4r+Cfiy7aS1sZLmNdU02V+WEcbsGbaBjeAY5ABv2PgnmvGX7fGg6vf6X4V+A+mLrOt6s6ILnWmXTrG3Zv4W3yLuYd2Z1Qdi1fhZ+XnlH7cfwI+Evw28J+EPEXgbw3Bosl7rBtLsQvKRLE0W8Ah3YDBVuVA61x/wCyZ8EPhN48+KvxE8KeNtCXVrXRI4ZrBJJpk8pTMVbPlSKWBDKPmJ6fWvfP+ChctzP8K/h7bXyxLqN9rUbssD+ZCZEtSJRE/wDEiySYU9xg965D9ihJG/aN+KEyD90umxox9GM8OP8A0E0Aa37Y37OPw08B/ByLx18MvDdtot94b1G3luGh3yGa2nPlkSGVnyFk8sjtgkV8JeFfHVx8Gvjv4e+ImhEx6bPNb3zwJkRyWV4NtzCV4BUqXXB46V+3X7Rukwax8A/iHY3HKnRbqXHX5rdfOU/gyA1/P/4y/e+C/BF+B+8Npcwk9crFNwPwyaAP3c/4JjeILTw7+018cPhL8OLgaz8OXK6ra3MBza21wsojWOM9CHWRk3LwwhBBIxX7lV/OZ/wTssvDXhH9snwlpPwsld9M174cWt3r0aTG4EeoSQxTTeaeQhE2zC8bN+3Aziv6M6ACiiigD//U/fyiiigDJ1vRNM8R6Xd6HrdrFfadqEMlvc286CSKaKVSro6nggg4INfzS/tXfsxav+yD44E+mCW9+EviS4b+zLtsu2j3MhLfY7huTsP/ACzc/eUZ+8rZ/pwri/iF4A8JfFHwbqvgHxxpkWraHrUJgureUcMh5yCOVdThlYYKsAQcivTyjNq2CrxxFF6r7muz8jty/H1MNVVWm9V+PkfylfCLxDq/hv8AaH0b4reFfAFx8WdO8FwF9V062tGu47dHDxiQOsciLIhcOhIIDD0yR9pftJ/t6/tv3nhvSdQ8H+AX+Enh/wAXXZ07R5LpFm1y+kPTyknClByo3LDgFlAfkV+4nwl+DXw4+B3hC38D/DHQrfQtJtzuKQjMk0mMGWaU5eSQ92Yk9hwAK/N//gp5ouv+EfEvwP8A2nLTTZdZ0H4W6+JtWtoxuKQyzW8qSnsBmApuPAZk55qM1zB4vETxElZyd7E4/FuvWlWatd3Py7+J/gT4HfB3xhcaD+1Vf+MPjD8Y2tLe51Gz068SDT7Sa7jEqWst7L5tzIyq6lmjUKM4APb5w8P/AAo0nWNS1XX9d0IaLp9+zfYtKSeSV7SJjld0rkuWUcZfknJI7V9OftieOvhlfftPr8ePhx4ntNe8J/EzTbd5zbyg3On3UMccMsdzb/62Ijy43+ZedzBc7Tjz2PxX4Vm+7rVi2f8Ap4jH8zXnnIcTY/CDQLHU7HUYr68mi0+USxW88gkjDA5HYYGQM461vaLpvxN+HvinVvF/wo8Yvol3rTE3MUkaukq7y4V8h1ZVJyMpx61vN4k8ORqGbVrNVPf7RHj891ZV54/8EWSkz67afRH8w/kgY0Aa/iXxt+094+0m48NeMfiBHBo96jQ3UVjbRwtPE33kcxRRFlI6gtg9wa8T+KHhLQtE8AaXZQtNJc6c5gshuG6V52DSblA56dF6cetdFc/GvwqJls9FtrzVrlzhI4Ytu5vQbvmP/fJr9AP2Jf2NfiT8b/itovxu+Nvhyfw34E8KyLdabpl8jRzajdxkNETFIqt5KsA7sygPgIoILEAH6sfsW/sk/Dn9mv4caRfaLo/keMtd02zk1y9nYy3DXDRK8sCMeI4lkJwigAkAtkgEfa1NUYAz1p1ABRRRQB//1f38ooooAY7qgyzBR71+fb/tg/Ev/hD/ABV4h0b4byeNLaxvtUttJ1fwldW2r6a8NoMxS3sbz280JXIWVOpZXKYXBr9AJlDYJ7V+HGvSQa/4a+IT+OPhb47tn8V+KdevdEXwNpE1g32e3UWUDau9u8LytKwLgOrAr838XIB9X/Bz9tX4i/ET9nz/AIWbqnwy1Sx1WDSUvFvpLeQ6HqE5uBARbG0+1XgTBLsTAdiq2TgZr5Q1v/go18dNWhvLy++Gug3mhKJbGfw9MdQmudRDttFwlw9oLdYCpyYpF3kAggEgVnfsxC8+GH7OniPwPD8Kvijc+PNS8MXFhewXtncro7PPOYNtgs7lImCziQ4jUFUcnAGa+a7b4ffFLwXqs3wz1Hw7r72ugTXWhrHa6LqNzeXIgeOG0uIZEkSyaK4iLOSZVVNvcEZAPpDxh4Y/ZR8M/DDwn8T1+DPhmx8eeP8AxBFoltYXo1IaOIpZQbi7SK5S1YwxW7ZMiQqqyNhScV86tafs1DTPEfjjxD+y8t/4SZrrVdEutP8AETaZcS+Ho7j7LFdyWU14bhw8oIDpEFOQAD1r6e8afBbXdL+HP7OF1D4O1i18Y/Cbx5Z+FbWPUF/cXVgs8k325/swlUW0rxRfveQg3D5uCfNNA/Zu+OHiT4kat4H0RtWtvGWgeCdQhu9bljurTSU8QS64NQjs7O5kRUeyMTLGFQFCu87eoABwvjjwV+xV4H+MiaHe/APWI/Anh+DT4PFGpG+v5f7P1PWYYZ7KPzft6RpGiylZS67iVO1eOe++A2l/saav4rTT/HH7Pz6LpHivVdVj8H69epdHRbrS9OieVZ7u4u7w5bETtIUiKqMe5rC+N/gH4n638f8A4najdeBfEt/e3PifwRPNe6RNMdBieG3tTdebb/K10AysIpRGfLwSxWvoPwx8P4rv9rnwX8N/DVr4n8WeE/BHiHxnfan/AG9pLppul2uq2Xk/Y4bubcLqKWYMVJJDBxgYJJAKeo/tI+IP2fvBPw/174f/AAe8A6ffeLbu40wJoUVxeLPc2908JntbjS7eZGh8pRIY2la5+8BG2K9w0/8Abo+IEfwg8c+ONQ0LS9a8TaZqVn4e0XS9Dt9YM0mtXsbusN7DqFpbSxqihX+UcgMuQxXP5teHvhh47stI+HPhfxZ8LtR0eOW78SyWl4uk6vq96ltBdtcW8iabp95afZiGuJY9xwxUbslcCvvX9iX4OeHfFp+Nvgfxv4Wu9OsZ7jSrdrl7PV/D95fxtGbgySRXd5PLHIkigCRJAxUDJwQKAMLQP+Cm3xNsdDs7fxT8OtP1DVYYwt3cW99qFtDJKB8zJEdMkKL/ALJdsepr9Xvhj4n1vxr4A0Hxd4i0yPRr/WLSK6ks4p/tKQiZd6gSlIy2VIPKKRnBGRX51ftQfsaeAfAHwV13xx8FtK19/Ffhx7PUIEg1rVLuaWC2uYpLlEhkuHVyYA/G0n0Ga+7vgP8AEbV/iz8N7L4gav4fuPDP9qz3TW1pdq8dwbOOZ47eaWNwGjaaNVk2HOAw5IoA9iooooA//9b9/K/Pb9t39ovWfhl4i+Fvwh8B6lc2Xivx7r9oZGso1muU0q3lHnpGjgq0lw2IkB6/N0xX6E5xXwt+2D8BvFPxX8WfB3xV8PtLT+3PC/iyznvNWUwifTtLWOUySqJnTzAkpR/LXcWIHGKAPgTQP2uv20tFtdSfT9U8L+Idb8Q2r+K7HQL+3ubi9s7K81L+zotLjuIJ4IBPA4y0LgyKN25i3yDuf2s/jv8AtH+Evj8fDXhnxjqfh/w9F4e06Z10qwF1bnU3aRblRIumai+RgfK23AxzT/Dv/BPbxvrviDWPAuv2a+GPCuieEU8PaX4h+0xXl7qGrQ61/aw1gWyENCZGLZjd9yg7dx5NZvxr/Yn+MvjX4ofELxpoPww8LapY6hpkmkWv2q7W0vdQ1K6jMsviNGjV0juBOxHlSFTt4ByN1AHQ/sd/G79o3xv8YvFfhvxh40vdU0OPwvNcabca3Yi2tYtW85VQsxsNOdwi/MyBcbc4Yn7vj/8Aw1P+1Zean45+NLfFrwpB4S+H8E2m2UQs5IrHxJPCQ1zLp9lJcrLPJAzKgk37SCMD0679mb9h34ieFPiBpNr8ZPhbbXugvYXFhe3j3OibIGmtzG1xG1nAl47kbkGXyd+5jkVX/wCGSv2gYfgH4j+Amg/Bbw5fWVxqGvDR9X1jU4P7R0q3vLs+Q1sDHMwBhSNgfNVifvAEUAet+Nvjj+0zbfAJfibbfEvw/q6TalpEk9x4OsIZ73TNLeGa51Dzre7uJIpJo4VVljDK3yt2ya+Sh+2B+1jCy2fiz4g3Og3tv4d0zUxEI/Dlq0r30csyyOupy27OJIxEwWAOQG6AkA/R3jL9nP8Aab8SfBHSPhn4e+DXhPwhf6Tf20hl0zVYUS+zpF9pk91dbIIyJF+0IwxvZiSOmTXk1x+wL+05qd1Lodj4Y8NeHbrTdO0JtN1+O/NzFb3ekWVxFJFHBLC8jrdvNiYyKERsOisFCgA774vftcfGnwt8Ov2bNeTxe+mP4+8Mz6hrc8baXZtc3SQ27qwm1GNreL5pG+UAZzgDpXh/wL/bp/aD8Y/ED4aaHrXjyS8/4SHxfDpeoWxfRJFfT3nZMC3t4hdIxUD99kRt1XqtfRfxN/Za/aQ+IXgzwJ8LPDnh2/8AC81p4bt9MvdWm8YvPpNgiySJLG9lDCsl1O0Z5YDYVKqSdtU9M/ZG+NPgX4l+BfBPwt0XxTp/h3wlrOlPd+J77xXbyaZd6XZbZLhYtJTE0fnEbFQ5C4K8qc0AYWuft0fHP4UfFf4rQa1HouqWFnrmhabFBdawbnTNFkvhJG4EkFuk+0BPNnARxEwKZZsCsT9mz9vv4ieLfB2u+A/ibrQuvs3h3XdYfxHoaTahrdi8eoi2hzaNCsTCJZhImAw8lVZ9p3Aer2H/AATW0PX/AIn/ABIvoba5+H9vB4q0fWfDeuWbpcXjW0MPm3iQF5G8stdHcGkQ7GUbUK5zL+zF+wr8SPAHgXVPGniXV74eNLvw14o8N22g6nJA9nANTvZZYJkuLfcUWbCyyLh/mkZsr90AHAr+1N+1PqXivw9pXwrvbPxlLYeBbWfULi+vrDQrO/u9ajZ7DUVt74pIs0BX96qyssmPuxbsV33gv9pzx7rv7O3wbOoeNbzw58QtZ8U/2PJeXdmNXs9Xl0+8Ftc211NawqkSz78xbWUkJ/rDy9eGv/wTz+P/AIs0RPDXxF0HQ9Qn8CeDdR03SdUV4BNq2o3dkkWnWwIVWSLTSpCSzYJfLDggr7hZ/s8ftXeI/wBnDwP8P9I8H+HvhzrHhPxjo+padbefFKtnaadbYlv7sQF4riaS73SFEIJVsHJ5oA838ZfH39rAfGfQvh9DrXxD0zTfEFrqV4LWPwfo8erBLZl2LaRtK6SxorYkkdgy8Hac1+z/AMPNQvtU8C+H9Q1SK/gvLixt2mTVIkgvxIUG77TFFlElJ5dU+UHIHGK/DXxB+xn8etS8G/Ex9W+DNh4o8Z6nqetTaZ4nm8RvZaiEuJC0MtvYqzQBT95EaVeuGxiv3H+Gumajovw68LaPrEZiv7DSrG3uEYhmWaKBEkUsCQSGBBIJFAH/2Q==
 
 */

#import "ViewController.h"
#import <arpa/inet.h>
#import <netinet/in.h>
#import <sys/socket.h>

@interface ViewController ()
//监听到的客户端ip地址
@property (weak, nonatomic) IBOutlet UILabel *client_ip;
//监听到的客户端端口
@property (weak, nonatomic) IBOutlet UILabel *client_port;
//服务器手动发送消息
@property (weak, nonatomic) IBOutlet UITextField *server_sendMSG;
//显示客户端发来的消息
@property (weak, nonatomic) IBOutlet UITextView *client_showMSG;
//连接状态
@property (nonatomic, weak) IBOutlet UILabel * status;
//监听按钮点击
@property (weak, nonatomic) IBOutlet UIButton *connectBtn;
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
//记录按钮状态
@property (nonatomic,assign) int flag;
@end

@implementation ViewController
{
    int _serverSocket;
    int _clientSocket;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    //开启服务
    [self startServer];
    
}

- (void)startServer{
    //按钮监听是否启动服务
    [self.connectBtn addTarget:self action:@selector(connectBtnEvent:) forControlEvents:UIControlEventTouchUpInside];
}


#pragma mark - 建立监听
- (void)connectAndlistenPort:(int)port{
    
    _serverSocket=socket(AF_INET, SOCK_STREAM , IPPROTO_TCP);
    //如果返回值不为-1,则成功
    if(_serverSocket != -1){
        NSLog(@"socket success");
        struct sockaddr_in addr;
        memset(&addr, 0, sizeof(addr));//清零操作
        addr.sin_len=sizeof(addr);
        addr.sin_family=AF_INET;
        addr.sin_port=htons(8888);
        addr.sin_addr.s_addr=INADDR_ANY;
        //绑定地址和端口号
        int bindAddr = bind(_serverSocket, (const struct sockaddr *)&addr, sizeof(addr));
        //开始监听
        if (bindAddr == 0) {
            NSLog(@"bind(绑定) success");
            int startListen = listen(_serverSocket, 5);//5为等待连接数目
            if(startListen == 0){
                NSLog(@"listen success");
                
                //回到主线程更新UI
                dispatch_async(dispatch_get_main_queue(), ^{
                    self.status.text = @"监听成功";
                });
                
            }else{
                dispatch_async(dispatch_get_main_queue(), ^{
                    self.status.text = @"监听失败";
                });
            }
        }
    }
}


#pragma mark - 阻塞直到客户端连接
- (void)accept{
    
    struct sockaddr_in peeraddr;
    socklen_t addrLen;
    addrLen=sizeof(peeraddr);
    NSLog(@"prepare accept");
    
    //接受到客户端clientSocket连接,获取到地址和端口
    int clientSocket=accept(_serverSocket, (struct sockaddr *)&peeraddr, &addrLen);
    _clientSocket = clientSocket;
    if (clientSocket != -1) {
        NSLog(@"accept success,remote address:%s,port:%d",inet_ntoa(peeraddr.sin_addr),ntohs(peeraddr.sin_port));
        //回到主线程更新UI
        dispatch_async(dispatch_get_main_queue(), ^{
            
            self.client_ip.text =[NSString stringWithUTF8String:inet_ntoa(peeraddr.sin_addr)];
            self.client_port.text = [NSString stringWithFormat:@"%d",ntohs(peeraddr.sin_port)];
            
        });
        
        char buf[1024];
        size_t len=sizeof(buf);
        
        //接受到客户端消息
        recv(clientSocket, buf, len, 0);
        NSString* str = [NSString stringWithCString:buf encoding:NSUTF8StringEncoding];
        NSData *data = [NSData dataWithBytes:buf length:recv(clientSocket, buf, len, 0)];
        
        //主线程更新UI
        dispatch_async(dispatch_get_main_queue(), ^{
            self.client_showMSG.text = str;
            NSLog(@"%@",str);
            self.imageView.image = [UIImage imageWithData:data];
        });
    }
}

#pragma mark - 关闭socket
- (void)connectBtnEvent:(UIButton *)sender {
    if (self.flag==0) {
        [self.connectBtn setTitle:@"断开连接" forState:UIControlStateNormal];
        dispatch_queue_t SERIAL_QUEUE =  dispatch_queue_create("SERIAL", DISPATCH_QUEUE_SERIAL);
        dispatch_async(SERIAL_QUEUE, ^{
            
            self.flag=1;
            [self connectAndlistenPort:1024];
            while (self.flag) {
                //扫描客户端连接
                [self accept];
            }
        });
        
        
    }else{
        
        [self.connectBtn setTitle:@"启动服务器" forState:UIControlStateNormal];
        self.status.text = @"监听失败";
        shutdown(_clientSocket, SHUT_RDWR);
        shutdown(_serverSocket, SHUT_RDWR);
        close(_clientSocket);
        close(_serverSocket);
        self.flag=0;
    }
}
#pragma mark - 发送消息

- (IBAction)sendBtn:(UIButton *)sender {
    
    UIImage *icoImage = [UIImage imageNamed:@"head"];
    NSData *imaged = UIImageJPEGRepresentation(icoImage, 1);
    NSString *imageStr = [imaged base64EncodedStringWithOptions:NSDataBase64Encoding64CharacterLineLength];
    [self sentAndRecv:_clientSocket msg:imageStr];
    [imageStr dataUsingEncoding:NSUTF8StringEncoding];
//    self.imageView.image = icoImage;
    NSData *decodeData = [[NSData alloc]initWithBase64EncodedString:imageStr options:(NSDataBase64DecodingIgnoreUnknownCharacters)];
    self.imageView.image = [UIImage imageWithData:[NSData dataWithData:decodeData]];
    [self sendDataWithType:@"img" clientSocket:_clientSocket data:imaged];
    
//    [self sentAndRecv:_clientSocket msg:_server_sendMSG.text];
}

//发送数据并等待返回数据
- (void)sentAndRecv:(int)clientSocket msg:(NSString *)msg {
    dispatch_queue_t q_con =  dispatch_queue_create("CONCURRENT", DISPATCH_QUEUE_CONCURRENT);
    dispatch_async(q_con, ^{
        
        const char *str = msg.UTF8String;
        send(clientSocket, str, strlen(str), 0);
        
//        char *buf[1024];
//        ssize_t recvLen = recv(clientSocket, buf, sizeof(buf), 0);
//
//        NSData *data = [NSData dataWithBytes:buf length:recv(clientSocket, buf, sizeof(buf), 0)];
//        NSString *recvStr = [[NSString alloc] initWithBytes:buf length:recvLen encoding:NSUTF8StringEncoding];
//        dispatch_async(dispatch_get_main_queue(), ^{
//
//            self.client_showMSG.text = recvStr;
//
//             self.imageView.image = [UIImage imageWithData:data];
//        });
        
    });
}

- (void)sendDataWithType:(NSString *)type clientSocket:(int)socket data:(NSData *)data
{
    dispatch_queue_t q_con =  dispatch_queue_create("CONCURRENT", DISPATCH_QUEUE_CONCURRENT);
    dispatch_sync(q_con, ^{
        NSString *st = [data base64EncodedStringWithOptions:NSDataBase64Encoding64CharacterLineLength];
        NSDictionary *dict = @{@"type":type,@"msg":st};
        NSError *parseError = nil;
        NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dict options:NSJSONWritingPrettyPrinted error:&parseError];
        NSString *sendMsg = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
        const char *str = sendMsg.UTF8String;
        send(socket, str, strlen(str), 0);
        
    });
}

@end
