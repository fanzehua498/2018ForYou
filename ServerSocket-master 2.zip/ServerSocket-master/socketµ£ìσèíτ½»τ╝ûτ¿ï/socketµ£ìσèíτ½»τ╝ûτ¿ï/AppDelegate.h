//
//  AppDelegate.h
//  socket服务端编程
//
//  Created by ZH on 16/10/16.
//  Copyright © 2016年 ZH. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

